CREATE FUNCTION check_login ("user" text, pass text) RETURNS boolean
	LANGUAGE plpgsql
AS $$
DECLARE exists BOOLEAN;
BEGIN
  SELECT (password = $2)
  INTO exists
  FROM employees
  WHERE login = $1;

  RETURN exists;
END;
$$
